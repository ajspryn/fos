<?php

namespace Modules\Admin\Http\Controllers;

use Illuminate\Routing\Controller;

class PasarPenggunaanController extends Controller
{
}
