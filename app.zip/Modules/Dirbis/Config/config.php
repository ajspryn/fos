<?php

return [
    'name' => 'Dirbis'
];
