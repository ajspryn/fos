<?php

return [
    'name' => 'Analis'
];
