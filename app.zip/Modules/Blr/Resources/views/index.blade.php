@extends('blr::layouts.main')

@section('content')
    
@endsection
