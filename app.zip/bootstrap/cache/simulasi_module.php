<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Simulasi\\Providers\\SimulasiServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Simulasi\\Providers\\SimulasiServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);