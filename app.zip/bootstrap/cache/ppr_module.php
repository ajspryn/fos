<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Ppr\\Providers\\PprServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Ppr\\Providers\\PprServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);