<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Umkm\\Providers\\UmkmServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Umkm\\Providers\\UmkmServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);