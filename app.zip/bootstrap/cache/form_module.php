<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Form\\Providers\\FormServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Form\\Providers\\FormServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);