<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Skpd\\Providers\\SkpdServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Skpd\\Providers\\SkpdServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);