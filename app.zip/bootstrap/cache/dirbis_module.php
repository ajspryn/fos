<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Dirbis\\Providers\\DirbisServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Dirbis\\Providers\\DirbisServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);