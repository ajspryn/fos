<?php

namespace Modules\Umkm\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class UmkmFoto extends Model
{
    protected $guarded = [
        'created_at'
    ];
}
