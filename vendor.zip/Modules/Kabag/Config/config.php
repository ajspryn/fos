<?php

return [
    'name' => 'Kabag'
];
