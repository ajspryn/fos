@extends('analis::layouts.main')

@section('content')
    <!-- BEGIN: Content-->
@endsection
