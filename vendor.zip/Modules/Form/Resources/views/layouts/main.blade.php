@include('form::layouts.header')

@yield('content')

@include('form::layouts.footer')