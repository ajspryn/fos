<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Analis\\Providers\\AnalisServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Analis\\Providers\\AnalisServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);