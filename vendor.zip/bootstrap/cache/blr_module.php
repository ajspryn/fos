<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Blr\\Providers\\BlrServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Blr\\Providers\\BlrServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);