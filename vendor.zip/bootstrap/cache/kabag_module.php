<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Kabag\\Providers\\KabagServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Kabag\\Providers\\KabagServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);