<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pasar\\Providers\\PasarServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pasar\\Providers\\PasarServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);